﻿using Emix.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Emix.Web.ControllersWepApi
{
    public class TestController : ApiController
    {
        private static TableData tableData;
        private static Random randomGenerator;

        public static List<Mobile> Mobiles{ get; set; }

        static TestController()
        {
            int mobilesLength = 2;
            Mobiles = new List<Mobile>();
            var colors = getColors();
            var pics = getPictures();
           
            for (int i = 0; i < mobilesLength; i++)
            {
                var mobile = new Mobile(i, i+"", "partner", i + " phone", "nice phone", i*10, colors, pics);
                Mobiles.Add(mobile);
            }      
            
        }

        private static List<string> getPictures()
        {
            var pics = new List<string>();
            pics.Add("\\img\\android.jpg");
            pics.Add("\\img\\iphone.jpg");
            return pics;
        }

        private static List<string> getColors()
        {
            var colors = new List<string>();
            colors.Add("Green");
            colors.Add("Blue");
            colors.Add("Red");
            return colors;
        }

        private decimal getRandom()
        {
            double val = randomGenerator.NextDouble();
            return (decimal)val * 1000;
        }

        public TestController() { }

        [HttpGet]
        public object getMobileDevice(int id)
        {
            var retVal = new Mobile();
            foreach (var mobile in Mobiles)
            {
                if(mobile.ID == id)
                {
                    retVal = mobile;
                    break;
                }
            }
            return Json(retVal);
        }

        [HttpGet]
        public object getMobiles()
        {
            return Json(Mobiles);
        }
    }

    public class TableData
    {
        public TableData()
        {
            this.Columns = new List<string>();
            this.Rows = new List<string>();
            this.Data = new List<List<decimal>>();
        }

        public List<string> Columns { get; set; }

        public List<string> Rows { get; set; }

        //list of rows
        public List<List<decimal>> Data { get; set; }
    }
 }
