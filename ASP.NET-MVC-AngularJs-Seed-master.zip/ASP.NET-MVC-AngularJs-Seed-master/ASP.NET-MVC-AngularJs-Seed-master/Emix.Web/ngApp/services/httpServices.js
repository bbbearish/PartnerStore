﻿
angular.module('emixApp.services').service('httpServices', ['$http', function ($http) {
    'use strict';

    var serverUrl = "http://localhost:52205/api/test/";

    return {
        getMobileDevice: function (id) {
            return $http({
                method: "GET",
                url: serverUrl + "getmobiledevice",
                cache: false,
                params: { id: id }
            });
        },
        getMobiles: function () {
            return $http({
                method: "GET",
                url: serverUrl + "getmobiles",
                cache: false
            });
        }
    };
}]);
